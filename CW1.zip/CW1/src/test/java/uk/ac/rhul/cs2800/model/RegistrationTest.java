package uk.ac.rhul.cs2800.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
/**
 * Represent 
 */
public class RegistrationTest {
  @Test
  public void testRegistrationCreation() {
    Student student = new Student(1, "Leand", "Hadergjonaj", "lhad", "lhad@gmail.com");
    Module module = new Module("CS2800", "Introduction to Java", true);
    Registration registration = new Registration(student, module);
    assertNotNull(registration);
  }
}
