package uk.ac.rhul.cs2800.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Grade class.
 */
public class GradeTest {

  /**
   * Tests the creation of a Grade object.
   */
  @Test
  public void testGradeCreation() {
    Module module = new Module("CS2800", "Introduction to Java", true);
    Grade grade = new Grade(90, module);
    assertEquals(90, grade.getScore());
    assertEquals(module, grade.getModule());
  }

}
