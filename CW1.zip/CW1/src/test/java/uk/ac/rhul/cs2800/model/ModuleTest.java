package uk.ac.rhul.cs2800.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
// 
public class ModuleTest {
  @Test
  public void testModuleCreation() {
    Module module = new Module("CS2800", "Introduction to Java", true);
    assertEquals("CS2800", module.getCode());
    assertEquals("Introduction to Java", module.getName());
    assertTrue(module.isMandatoryNonCondonable());
  }
}
