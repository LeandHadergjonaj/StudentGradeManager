package uk.ac.rhul.cs2800.model;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uk.ac.rhul.cs2800.exception.NoGradeAvailableException;
import uk.ac.rhul.cs2800.exception.NoRegistrationException;

/**
 * Unit tests for the Student class.
 */
public class StudentTest {

  private Student student;
  private Module module;
  private Grade grade;

  /**
   * Sets up the test environment before each test.
   */
  @BeforeEach
  public void setUp() {
    student = new Student(1, "Leand", "Hadergjonaj", "lhad", "lhad@gmail.com");
    module = new Module("CS2800", "Introduction to Java", true);
    grade = new Grade(85, module);
  }

  /**
   * Tests adding a grade to the student.
   */
  @Test
  public void testAddGrade() {
    student.registerModule(module);
    assertDoesNotThrow(() -> student.addGrade(grade));
  }

  /**
   * Tests registering a module for the student.
   */
  @Test
  public void testRegisterModule() {
    student.registerModule(module);
    assertDoesNotThrow(() -> {
      try {
        student.getGrade(module);
      } catch (NoGradeAvailableException e) {
        // Expected behavior if no grade is available
      }
    });
  }

  /**
   * Tests computing the average grade for the student.
   *
   * @throws NoGradeAvailableException if no grades are available
   * @throws NoRegistrationException if the student is not registered for the module
   */
  @Test
  public void testComputeAverage() throws NoGradeAvailableException, NoRegistrationException {
    student.registerModule(module);
    student.addGrade(new Grade(80, module));
    student.addGrade(new Grade(90, module));
    assertEquals(85.0, student.computeAverage());
  }

  /**
   * Tests that an exception is thrown when attempting to compute an average with no grades.
   */
  @Test
  public void testNoGradesThrowsException() {
    assertThrows(NoGradeAvailableException.class, () -> student.computeAverage());
  }

  /**
   * Tests that an exception is thrown when attempting to get a grade for an unregistered module.
   */
  @Test
  public void testGetGradeThrowsNoRegistrationException() {
    assertThrows(NoRegistrationException.class, () -> student.getGrade(module));
  }
}
