package uk.ac.rhul.cs2800.model;

/**
 * Represents a module with its code, name, and whether it is mandatory non-condonable.
 */
public class Module {

  /**
   * The code of the module.
   */
  private final String code;

  /**
   * The name of the module.
   */
  private final String name;

  /**
   * Indicates whether the module is mandatory non-condonable.
   */
  private final boolean mnc;

  /**x
   * Constructs a new Module.
   *
   * @param codeValue the module code
   * @param nameValue the module name
   * @param mncValue true if the module is mandatory non-condonable, otherwise false
   */
  public Module(final String codeValue, final String nameValue,
      final boolean mncValue) {
    this.code = codeValue;
    this.name = nameValue;
    this.mnc = mncValue;
  }

  /**
   * Gets the code of the module.
   *
   * @return the module code
   */
  public String getCode() {
    return code;
  }

  /**
   * Gets the name of the module.
   *
   * @return the module name
   */
  public String getName() {
    return name;
  }

  /**
   * Checks if the module is mandatory non-condonable.
   *
   * @return true if the module is mandatory non-condonable, otherwise false
   */
  public boolean isMandatoryNonCondonable() {
    return mnc;
  }

}
