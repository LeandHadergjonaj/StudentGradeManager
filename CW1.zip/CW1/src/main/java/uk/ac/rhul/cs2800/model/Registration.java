package uk.ac.rhul.cs2800.model;

/**
 * Represents the registration of a student to a module.
 */
public class Registration {

  /**
   * The student being registered.
   */
  private final Student student;

  /**
   * The module for which the student is registering.
   */
  private final Module module;

  /**
   * Constructs a new Registration.
   *
   * @param studentValue the student being registered
   * @param moduleValue the module the student is registering for
   */
  public Registration(final Student studentValue, final Module moduleValue) {
    this.student = studentValue;
    this.module = moduleValue;
  }

  /**
   * Gets the student.
   *
   * @return the student
   */
  public Student getStudent() {
    return student;
  }

  /**
   * Gets the module.
   *
   * @return the module
   */
  public Module getModule() {
    return module;
  }
}
