package uk.ac.rhul.cs2800.model;

/**
 * Represents a grade for a student in a particular module.
 */
public class Grade {

  /**
   * The score of the grade.
   */
  private final int score;

  /**
   * The module the grade is associated with.
   */
  private final Module module;

  /**
   * Constructs a new Grade.
   *
   * @param scoreValue the score achieved by the student
   * @param moduleValue the module the grade is for
   */
  public Grade(final int scoreValue, final Module moduleValue) {
    this.score = scoreValue;
    this.module = moduleValue;
  }

  /**
   * Gets the score of the grade.
   *
   * @return the score
   */
  public int getScore() {
    return score;
  }

  /**
   * Gets the module associated with this grade.
   *
   * @return the module
   */
  public Module getModule() {
    return module;
  }
}
