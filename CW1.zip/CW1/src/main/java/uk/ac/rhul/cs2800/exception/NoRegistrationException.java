package uk.ac.rhul.cs2800.exception;

/**
 * Exception thrown when attempting to access a grade for a module that the student is not
 * registered in.
 */
public class NoRegistrationException extends Exception {

  private static final long serialVersionUID = 1L;

  /**
   * Constructs a new NoRegistrationException with the given message.
   *
   * @param messageValue the detail message
   */
  public NoRegistrationException(final String messageValue) {
    super(messageValue);
  }
}
