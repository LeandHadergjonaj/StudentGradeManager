package uk.ac.rhul.cs2800.model;

import java.util.ArrayList;
import java.util.List;
import uk.ac.rhul.cs2800.exception.NoGradeAvailableException;
import uk.ac.rhul.cs2800.exception.NoRegistrationException;

/**
 * Represents a student with details, registered modules, and grades.
 */
public class Student {

  /**
   * The student's ID.
   */
  private final long id;

  /**
   * The student's first name.
   */
  private final String firstName;

  /**
   * The student's last name.
   */
  private final String lastName;

  /**
   * The student's username.
   */
  private final String username;

  /**
   * The student's email address.
   */
  private final String email;

  /**
   *  list of grades the student has received.
   */
  private final List<Grade> grades;

  /**
   *  list of modules the student is registered for.
   */
  private final List<Module> modules;

  /**
   * Constructs a new Student with the given details.
   *
   * @param idValue the student's ID
   * @param firstNameValue the student's first name
   * @param lastNameValue the student's last name
   * @param usernameValue the student's username
   * @param emailValue the student's email address
   */
  public Student(final long idValue, final String firstNameValue, final String lastNameValue,
      final String usernameValue, final String emailValue) {
    this.id = idValue;
    this.firstName = firstNameValue;
    this.lastName = lastNameValue;
    this.username = usernameValue;
    this.email = emailValue;
    this.grades = new ArrayList<>();
    this.modules = new ArrayList<>();
  }

  /**
   * Computes the average grade for the student.
   *
   * @return the average grade as a float
   * @throws NoGradeAvailableException if no grades are available
   */
  public float computeAverage() throws NoGradeAvailableException {
    if (grades.isEmpty()) {
      throw new NoGradeAvailableException("No grades available to compute average.");
    }
    int total = grades.stream().mapToInt(Grade::getScore).sum();
    return (float) total / grades.size();
  }

  /**
   * Adds a grade to the student's list of grades.
   *
   * @param gradeValue the grade to add
   * @throws NoRegistrationException if the student is not registered for the module
   */
  public void addGrade(final Grade gradeValue) throws NoRegistrationException {
    if (!modules.contains(gradeValue.getModule())) {
      throw new NoRegistrationException(
          "Student is not registered in the module: " + gradeValue.getModule().getName());
    }
    grades.add(gradeValue);
  }

  /**
   * Gets the grade for a specific module.
   *
   * @param moduleValue the module to get the grade for
   * @return the grade for the module
   * @throws NoGradeAvailableException if no grade is available for the module
   * @throws NoRegistrationException if the student is not registered for the module
   */
  public Grade getGrade(final Module moduleValue)
      throws NoGradeAvailableException, NoRegistrationException {
    if (!modules.contains(moduleValue)) {
      throw new NoRegistrationException(
          "Student is not registered in the module: " + moduleValue.getName());
    }
    return grades.stream().filter(g -> g.getModule().equals(moduleValue)).findFirst()
        .orElseThrow(() -> new NoGradeAvailableException(
            "No grade available for module: " + moduleValue.getName()));
  }

  /**
   * Registers the student for a module.
   *
   * @param moduleValue the module to register
   */
  public void registerModule(final Module moduleValue) {
    modules.add(moduleValue);
  }
}
